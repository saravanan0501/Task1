var config = {
    'map': {
        '*': {
            'mage/validation': 'Task_Listing/js/validation'
        }
    },
    config: {
        mixins: {
            'Task_Listing/js/validation': {
                'Task_Listing/js/validation-mixin': true
            }
        }
    }
};